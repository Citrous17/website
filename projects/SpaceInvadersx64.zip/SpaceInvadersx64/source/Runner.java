import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.sound.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Runner extends PApplet {

//Kyle Stallings 
//Space Invaders
Invader matrix[][];
int x[] = {50,100,150,200,250,300,350,400,450,500,550};
int tankX, bulletX, bulletY,invaderbulletX, invaderbulletY, score, w, l;
boolean goingRight, dropDown, tankFiring, isInvaderShooting, gameOver, won;
PImage invaderImages[]= new PImage[3], shieldImage, tankImage, explosionImage;
PFont font;

SoundFile AlienShot, GameOverLose, GameOverWin, tankShot;

Invader alien, farLeftAlien, farRightAlien;

public void setup() {
  
  rectMode(CORNER);
  background(0);
  loadImages();
  startingValues();
  setUpFont();
  setUpInvaders();
}



public void draw() {
  if(gameOver == false) {  
  background(0);
  drawLabels();
  drawInvaders();
  gameOver = checkForGameOver(); 
  drawShields();
  drawTank();
  moveInvaders();
  checkEdges();
  if(tankFiring)
  drawTankBullet();
  int shouldHeShoot = (int)random(10);
  if(shouldHeShoot == 1 && !isInvaderShooting)
    whoShoots();
  if(isInvaderShooting)
   drawInvaderBullet();
  }
 else {
   if(score == 825) {
   background(0); 
   text("YOU MASTERED ",0,500);
   text("SPACE INVADERS", 0, 550);
   text("GAME OVER", 200,100);
   text("SCORE", 200, 300);
   text(score, 500, 300);
   } else {
   invaderbulletX = 0;
   background(0); 
   text("GAME OVER", 200,100);
   text("SCORE", 200, 300);
   text(score, 500, 300);

   }
  }
 
  
  
}
public boolean checkForGameOver() {
 if(alien.getY()>=500 && alien.isAlive()) {
  GameOverLose = new SoundFile(this, "gameOverMusic.wav");
  GameOverLose.play();
   return true;   
 }
 if(invaderbulletY>=550 && invaderbulletX>=tankX && invaderbulletX<=tankX+50) {
  GameOverLose = new SoundFile(this, "gameOverMusic.wav");
  GameOverLose.play(); 
   return true; 
 }
 if(score == 825)  {
  GameOverWin = new SoundFile(this, "gameOverWinMusic.wav");
  GameOverWin.play();
   return true;
 }
 
 return false;
}

public void whoShoots() {
  int who = (int)random(11);
  for(int r =4; r>=0; r--) {
  alien = matrix[r][who];
  if(alien.isAlive() == true) {
   shootFrom(alien);
   return;     
    }
  }
}

public void shootFrom(Invader alien) {
  invaderbulletX = alien.getX()+20;
  invaderbulletY = alien.getY()+50;
  AlienShot = new SoundFile(this, "AlienShotSound.wav");
  AlienShot.play();
  isInvaderShooting = true;
}

public void drawInvaderBullet() { 

    if(invaderbulletY>=500) {

    if(invaderbulletX>=150 && invaderbulletX<=200 || invaderbulletX>=300 && invaderbulletX<=350 || invaderbulletX>=450 && invaderbulletX<=500 || invaderbulletX>=600 && invaderbulletX<=650) {
    isInvaderShooting = false;
    invaderbulletY= -20;
      }
    }
  if(isInvaderShooting && invaderbulletY<=600) {
   fill(255,0,0);
   rect(invaderbulletX,invaderbulletY,5,5); 
   invaderbulletY +=5;
  } else {
   isInvaderShooting = false;
  }
}

public boolean checkForExplosion(Invader alien) {
  if(bulletX>=alien.getX() && bulletX<=alien.getX()+50 && bulletY>alien.getY() && bulletY<alien.getY()+50) {
    bulletX = -10;
    tankFiring = false;
    return true;
  }  
  return false;
}

public void explode(Invader alien) {
  image(explosionImage,alien.getX(),alien.getY());
  alien.die();
  score = score + alien.getPoints();
}

public void keyPressed() {
  if(gameOver && key == 'r') {
    startingValues();
    setup();
    
  }
  if(key ==' ' && tankFiring == false) {
    bulletX = tankX+20;
    bulletY = 575;
    tankFiring =true;
    tankShot = new SoundFile(this, "tankShotSound.wav");
    tankShot.play();
  }
  if(keyCode == RIGHT && tankX<700) {
   tankX+=25; 
  }
  if(keyCode == LEFT && tankX>0) {
   tankX-=25; 
  }
}

public void drawTankBullet() {

  
    if(bulletY<=550) {

    if(bulletX>=150 && bulletX<=200 || bulletX>=300 && bulletX<=350 || bulletX>=450 && bulletX<=500 || bulletX>=600 && bulletX<=650) {
    tankFiring = false;
    bulletY=0;
      }
    }
  if(bulletY>0) {
      bulletY-=20;
  } else {

  tankFiring = false;
  }
  
  fill(255);
  rect(bulletX,bulletY,5,5);
}

public void moveInvaders() {
  for(int r = 0; r<5; r++) {
   for(int c = 0; c<11; c++) {
     alien = matrix[r][c];
     
     int currentY = alien.getY();
     int currentX = alien.getX();

     if(goingRight) {
     alien.setX(currentX+1);
     } else {
      alien.setX(currentX-1); 
     }
     if(dropDown) {
     alien.setY(currentY+10);
     }
   }
  }
  dropDown = false;
}

public void checkEdges() {
  farRightAlien = matrix[0][10];
  farLeftAlien = matrix[0][0];
  if(farRightAlien.getX() == 700) {
       goingRight = false;
       dropDown = true;

   }
  if(farLeftAlien.getX() <=0) {
       goingRight = true; 
       dropDown = true;
  }
}

public void loadImages() {  
  invaderImages[0] = loadImage("invader1.png");
  invaderImages[1] = loadImage("invader2.png");
  invaderImages[2] = loadImage("invader3.png");
  shieldImage = loadImage("shield.png");
  tankImage = loadImage("shooter.png");
  explosionImage = loadImage("explosion.png");
}

public void setUpFont() {
  font = loadFont("8-Bit.vlw");
}

public void setUpInvaders() {
  matrix = new Invader[5][11];
  for(int i = 0; i<11; i++) {
   matrix[0][i] = new Invader(x[i], 75,25, true, invaderImages[0]); 
   matrix[1][i] = new Invader(x[i], 125,20, true, invaderImages[1]); 
   matrix[2][i] = new Invader(x[i], 175,15, true, invaderImages[1]); 
   matrix[3][i] = new Invader(x[i], 225,10, true, invaderImages[2]); 
   matrix[4][i] = new Invader(x[i], 275,5, true, invaderImages[2]); 
  }
}

public void drawLabels() {
  textFont(font);
  fill(255,0,0);
  text("SPACE INVADERS", 32,48);
}

public void drawInvaders() {
  for(int r = 4; r>=0; r--) {
    for(int c = 0; c<11; c++) {
     alien = matrix[r][c];
     if(alien.isAlive()) {
    if(checkForExplosion(alien)==true)
    explode(alien);
    else image(alien.getImage(), alien.getX(), alien.getY(), 50, 50);
  }
    }
  }
}


public void drawTank() {
  image(tankImage,tankX,550, 50, 50);
}

public void drawShields() {
 
 image(shieldImage, 150, 500, 50, 50);
 image(shieldImage, 300, 500, 50, 50);
 image(shieldImage, 450, 500, 50, 50);
 image(shieldImage, 600, 500, 50, 50);
}

public void startingValues() {
  w =0; l = 0;
 tankX = 375;
 invaderbulletX = -10;
 goingRight = true;
 dropDown = false;
 tankFiring = false;
 gameOver = false;
}
//Kyle Stallings
class Invader {
 int x,y,points;
 boolean alive;
 PImage image;
 
 Invader() {
  x = 0;
  y = 0;
  points = 0;
  alive = true;
  image = null;
 }
 Invader(int xPos, int yPos, int p, boolean a, PImage I) {
  x = xPos;
  y = yPos;
  points = p;
  alive = a;
  image = I;
 }
 public int getX() {
  return x; 
 }
  public int getY() {
  return y; 
 }
 public int getPoints() {
  return points; 
 }
 public boolean isAlive() {
  return alive; 
 }
 public PImage getImage() {
  return image;
 }
 public void setX(int tx) {
  x = tx; 
 }
 public void setY(int ty) {
  y = ty; 
 }
 public void setPoints(int tp) {
  points = tp; 
 }
 public void die() {
  alive = false;
 }
}
  public void settings() {  size(750,600); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Runner" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
